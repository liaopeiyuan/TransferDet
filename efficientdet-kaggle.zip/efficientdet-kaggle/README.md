This is the inference code used on Kaggle environment for the CVPPP submission.
